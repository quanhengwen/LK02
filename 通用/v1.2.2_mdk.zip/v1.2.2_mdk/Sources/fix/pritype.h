
#ifndef uchar
typedef unsigned char uchar;
#endif

#ifndef ushort
typedef unsigned short ushort;
#endif


#ifndef uint 
typedef unsigned int uint;
#endif


#ifndef ulong
typedef unsigned long ulong;
#endif








